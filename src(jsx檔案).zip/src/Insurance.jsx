import { createRoot } from 'react-dom/client'
import { StrictMode } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import OtherModel from './InsuranceComponents/OtherModel.jsx'
import ModelDetail from './InsuranceComponents/ModelDetail.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter basename="/ai_insurance_platform/">
      <Routes>
        <Route path="/" element={<OtherModel />} />
        <Route path="/model/:id" element={<ModelDetail />} />
      </Routes>
    </BrowserRouter>
  </StrictMode>
)
