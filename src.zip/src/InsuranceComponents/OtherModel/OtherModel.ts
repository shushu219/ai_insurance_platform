//模型搜尋欄位
export interface FilterForm {
  model: string
  company: string
  accuracy: string
}